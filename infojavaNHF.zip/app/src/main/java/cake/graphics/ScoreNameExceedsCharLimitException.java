package cake.graphics;

public class ScoreNameExceedsCharLimitException extends Exception{

}
